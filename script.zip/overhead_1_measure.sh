sudo xentrace -D -e 0x24000 -S 1024 -M 100M -T 30 $1.bin

mv $1.bin ~/Desktop/data/overhead/